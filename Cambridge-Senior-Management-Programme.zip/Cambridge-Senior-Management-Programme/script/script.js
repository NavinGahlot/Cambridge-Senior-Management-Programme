﻿
//Animation
$(function () {
    if ($('.wow').length) {
        new WOW().init();
    }
});

/*Slider*/
$('#whySlider').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    dots: true, useTransform: false, arrows: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 3, centerMode: true,
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 1, centerMode: true, centerPadding: '20px',
            }
        }
    ]

});

$('#profileSlider').slick({
    slidesToShow: 2,
    slidesToScroll: 1,
    dots: true, useTransform: false, arrows: true, infinite:false,
    responsive: [
        
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 1
            }
        }
    ]

});
$('#curriculumSlider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    dots: true, useTransform: false, arrows: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 1
            }
        }
    ]

});
/*  Scroll to Top*/

var scrollToTop = function () {
    var windowWidth = $(window).width(),
        didScroll = false;

    var $arrow = $('#back-to-top');

    $arrow.click(function (e) {
        e.preventDefault();
        $('body,html').animate({ scrollTop: "0" }, 700);
    })

    $(window).scroll(function () {
        didScroll = true;
    });

    setInterval(function () {
        if (didScroll) {
            didScroll = false;
            if ($(window).scrollTop() > $('header').height()) {
                $arrow.addClass('stuck');
            } else {
                $arrow.removeClass('stuck');
            }
        }
    }, 250);
}
scrollToTop();

/*Next Section*/

$('.MainMenu li  a[href^="#"]').on('click', function (event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();

            $('html, body').stop().animate({
                scrollTop: target.offset().top - 150
            }, 1200);
    }
    $('.MainMenu').removeClass('show');
    $('.navbar-toggler').addClass('collapsed');
    
    });